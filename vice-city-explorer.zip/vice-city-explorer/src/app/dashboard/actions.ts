"use server";
import { z } from "zod";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

const schema = z.object({
  name: z.string().min(2), district: z.string().min(2), category: z.string().min(2),
  description: z.string().min(10), lat: z.coerce.number().min(-90).max(90), lng: z.coerce.number().min(-180).max(180),
  image_url: z.string().url().optional().or(z.literal("")),
});

export type FormState = { error: string | null; ok?: boolean };

export async function addLocation(_: FormState, form: FormData): Promise<FormState> {
  const parsed = schema.safeParse(Object.fromEntries(form));
  if (!parsed.success) return { error: parsed.error.issues.map((i) => `${String(i.path[0])}: ${i.message}`).join(", ") };
  const supabase = await createClient();
  const v = parsed.data;
  const slug = v.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
  const { error } = await supabase.from("locations").insert({ ...v, slug, image_url: v.image_url || null });
  if (error) return { error: error.message };
  revalidatePath("/"); revalidatePath("/locations"); revalidatePath("/map");
  return { error: null, ok: true };
}

export async function signOut() {
  await (await createClient()).auth.signOut();
  redirect("/");
}
