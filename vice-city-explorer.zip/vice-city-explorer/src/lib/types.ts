export type Location = {
  id: string; slug: string; name: string; district: string; category: string;
  description: string; lat: number; lng: number; image_url: string | null; created_at: string;
};
