"use client";
import Link from "next/link";
import { motion } from "framer-motion";
import { MapPin, Compass } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative h-screen min-h-[640px] overflow-hidden sunset-bg flex items-center">
      {/* Original synthwave sun */}
      <div className="absolute right-[8%] md:right-[14%] bottom-[30%] w-[min(60vw,440px)] aspect-square rounded-full"
        style={{ background: "linear-gradient(180deg,#FFC857 0%,#FF3CAC 60%,#8B5CF6 100%)",
          maskImage: "repeating-linear-gradient(180deg,#000 0 18px,transparent 18px 24px)", opacity: .55 }} />
      {/* Palm silhouettes (original SVG) */}
      {[["left-[4%]", 1], ["right-[6%]", -1]].map(([pos, flip]) => (
        <svg key={String(pos)} viewBox="0 0 200 400" className={`absolute bottom-[28%] ${pos} h-[45vh] fill-ink`} style={{ transform: `scaleX(${flip})` }}>
          <path d="M100 400 C96 300 92 200 104 120 L110 120 C100 200 106 300 110 400Z" />
          <path d="M106 120 C70 90 30 100 0 130 C40 105 80 108 106 124Z M106 120 C140 80 180 85 200 110 C165 95 135 100 108 126Z M106 118 C90 70 60 50 30 50 C70 65 92 90 104 124Z M108 118 C125 70 155 55 185 60 C150 75 125 95 110 124Z M106 118 C108 80 100 40 90 20 C112 45 116 85 110 122Z" />
        </svg>
      ))}
      <div className="absolute bottom-0 inset-x-0 h-[30%] overflow-hidden bg-ink"><div className="grid-floor absolute inset-0 h-[200%]" /></div>
      <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-ink/60" />

      <div className="relative z-10 mx-auto max-w-7xl px-6 w-full">
        <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-cyan uppercase tracking-[0.4em] text-xs mb-4">Unofficial fan exploration platform</motion.p>
        <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .15 }}
          className="font-display font-bold text-5xl md:text-8xl leading-[0.95] max-w-4xl">
          Explore the <span className="text-gradient">neon state</span> of mind.
        </motion.h1>
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .4 }} className="mt-6 text-lg text-muted max-w-xl">
          Districts, landmarks and hidden spots — mapped, catalogued and shared by the community.
        </motion.p>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .6 }} className="mt-10 flex flex-wrap gap-4">
          <Link href="/map" className="inline-flex items-center gap-2 rounded-full bg-pink text-ink font-semibold px-7 py-3.5 hover:shadow-[0_0_30px_#FF3CAC80] transition"><MapPin size={18} /> Open the map</Link>
          <Link href="/locations" className="inline-flex items-center gap-2 rounded-full glass px-7 py-3.5 hover:border-cyan transition"><Compass size={18} /> Browse locations</Link>
        </motion.div>
      </div>
    </section>
  );
}
