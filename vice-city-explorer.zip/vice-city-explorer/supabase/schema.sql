-- Vice City Explorer — run in Supabase SQL editor
create table public.profiles (
  id uuid primary key references auth.users on delete cascade,
  username text unique,
  role text not null default 'member' check (role in ('member','admin')),
  created_at timestamptz default now()
);

create table public.locations (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  district text not null,
  category text not null,
  description text not null,
  lat double precision not null,
  lng double precision not null,
  image_url text,
  created_by uuid references public.profiles(id) default auth.uid(),
  created_at timestamptz default now()
);

create table public.favorites (
  user_id uuid references public.profiles(id) on delete cascade,
  location_id uuid references public.locations(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (user_id, location_id)
);

-- Auto-create a profile on signup
create function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, username) values (new.id, split_part(new.email, '@', 1));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create function public.is_admin() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'admin');
$$;

alter table profiles enable row level security;
alter table locations enable row level security;
alter table favorites enable row level security;

create policy "profiles readable" on profiles for select using (true);
create policy "update own profile" on profiles for update using (auth.uid() = id) with check (role = (select role from profiles where id = auth.uid()));

create policy "locations readable" on locations for select using (true);
create policy "admins insert" on locations for insert with check (public.is_admin());
create policy "admins update" on locations for update using (public.is_admin());
create policy "admins delete" on locations for delete using (public.is_admin());

create policy "own favorites" on favorites for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- After signing up, make yourself admin:
-- update profiles set role = 'admin' where id = (select id from auth.users where email = 'you@example.com');
