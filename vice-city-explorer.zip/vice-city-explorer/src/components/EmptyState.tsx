export default function EmptyState({ reason }: { reason: string | null }) {
  const notConfigured = reason === "not-configured";
  return (
    <div className="glass rounded-2xl p-10 text-center max-w-xl mx-auto">
      <p className="font-game text-pink tracking-widest text-sm mb-3">{notConfigured ? "DATABASE NOT CONNECTED" : reason ? "SOMETHING WENT WRONG" : "NO LOCATIONS YET"}</p>
      <p className="text-muted text-sm">
        {notConfigured
          ? "Add your Supabase URL and anon key to .env.local, then run supabase/schema.sql. Locations will load here from the database."
          : reason ?? "Sign in as an admin to add the first location."}
      </p>
    </div>
  );
}
