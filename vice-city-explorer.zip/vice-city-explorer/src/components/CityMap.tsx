"use client";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import type { Location } from "@/lib/types";

const icon = L.divIcon({
  className: "",
  html: '<div style="width:18px;height:18px;border-radius:50%;background:#FF3CAC;border:3px solid #07070D;box-shadow:0 0 14px #FF3CAC"></div>',
  iconSize: [18, 18], iconAnchor: [9, 9],
});

export default function CityMap({ locations }: { locations: Location[] }) {
  // Real-world Miami used as the base map for the fictional city.
  return (
    <MapContainer center={[25.775, -80.19]} zoom={12} className="h-full w-full rounded-2xl" scrollWheelZoom>
      <TileLayer attribution='&copy; OpenStreetMap contributors &copy; CARTO'
        url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png" />
      {locations.map((l) => (
        <Marker key={l.id} position={[l.lat, l.lng]} icon={icon}>
          <Popup><strong>{l.name}</strong><br />{l.district} · {l.category}</Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}
