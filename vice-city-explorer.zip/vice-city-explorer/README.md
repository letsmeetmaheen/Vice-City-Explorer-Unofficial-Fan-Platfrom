# Vice City Explorer — Phase 1

Unofficial fan-made exploration platform. Not affiliated with Rockstar Games.

## Run it
1. `npm install`
2. Create a free project at supabase.com → SQL Editor → run `supabase/schema.sql`
3. Copy `.env.example` to `.env.local` and paste your project URL + anon key (Settings → API)
4. `npm run dev` → http://localhost:3000
5. Sign up on /login, then run the `update profiles set role='admin'…` line at the bottom of the schema to unlock the admin form.

## What's in Phase 1
- Neon design system (Tailwind v4 theme in `globals.css`), Inter / Space Grotesk / Orbitron
- Cinematic intro: skippable, remembered, skipped automatically for reduced-motion
- Homepage hero with original synthwave art (CSS/SVG, no third-party assets)
- Locations list + Leaflet/OpenStreetMap dark map, both read live from Supabase
- Real email/password auth (Supabase), session middleware, protected dashboard
- Admin-only "add location" with Zod validation, enforced by Row Level Security
- Honest empty/error states — no fake data

## Next phases
Location detail pages & favourites UI · image upload to Supabase Storage · news/CMS · Three.js scene · realtime community feed · Recharts stats · tests & Vercel deploy
