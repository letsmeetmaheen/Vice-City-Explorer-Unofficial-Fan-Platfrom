import Intro from "@/components/Intro";
import Hero from "@/components/Hero";
import LocationCard from "@/components/LocationCard";
import EmptyState from "@/components/EmptyState";
import { getLocations } from "@/lib/data";
import Link from "next/link";

export const dynamic = "force-dynamic";

const features = [
  ["Interactive map", "Every location pinned on a live map with custom neon markers.", "text-pink"],
  ["Real accounts", "Sign up with email, save favourites, and contribute spots.", "text-cyan"],
  ["Admin tools", "Moderators add and edit locations straight from the dashboard.", "text-gold"],
];

export default async function Home() {
  const { data, error } = await getLocations();
  return (
    <>
      <Intro />
      <Hero />
      <section className="mx-auto max-w-7xl px-6 py-24 grid md:grid-cols-3 gap-6">
        {features.map(([t, d, c]) => (
          <div key={t} className="glass rounded-2xl p-8">
            <h3 className={`font-game text-sm tracking-widest ${c}`}>{t.toUpperCase()}</h3>
            <p className="mt-3 text-muted">{d}</p>
          </div>
        ))}
      </section>
      <section className="mx-auto max-w-7xl px-6 pb-28">
        <div className="flex items-end justify-between mb-10">
          <h2 className="font-display text-4xl md:text-5xl font-bold">Featured <span className="text-gradient">locations</span></h2>
          <Link href="/locations" className="text-sm text-cyan hover:underline">View all →</Link>
        </div>
        {data.length ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">{data.slice(0, 6).map((l) => <LocationCard key={l.id} loc={l} />)}</div>
        ) : <EmptyState reason={error} />}
      </section>
    </>
  );
}
