"use client";
import Link from "next/link";
import { useState } from "react";
import { Menu, X } from "lucide-react";

const links = [["Home", "/"], ["Locations", "/locations"], ["Map", "/map"], ["Dashboard", "/dashboard"]];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <header className="fixed top-0 inset-x-0 z-50 glass !border-x-0 !border-t-0">
      <nav className="mx-auto max-w-7xl flex items-center justify-between px-6 h-16">
        <Link href="/" className="font-game tracking-[0.2em] text-sm"><span className="text-pink">VICE</span> CITY <span className="text-cyan">EXPLORER</span></Link>
        <div className="hidden md:flex items-center gap-8 text-sm">
          {links.map(([l, h]) => <Link key={h} href={h} className="text-muted hover:text-white transition">{l}</Link>)}
          <Link href="/login" className="rounded-full bg-pink text-ink font-semibold px-5 py-2 hover:bg-white transition">Sign in</Link>
        </div>
        <button className="md:hidden" aria-label="Menu" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
      </nav>
      {open && (
        <div className="md:hidden flex flex-col gap-4 px-6 pb-6">
          {links.map(([l, h]) => <Link key={h} href={h} onClick={() => setOpen(false)}>{l}</Link>)}
          <Link href="/login" onClick={() => setOpen(false)} className="text-pink">Sign in</Link>
        </div>
      )}
    </header>
  );
}
