export default function Footer() {
  return (
    <footer className="border-t border-white/10 py-10 text-center text-xs text-muted px-6">
      <p className="font-game tracking-widest text-white/70 mb-2">VICE CITY EXPLORER</p>
      <p>Unofficial fan project. Not affiliated with, endorsed by, or connected to Rockstar Games or Take-Two Interactive.</p>
    </footer>
  );
}
