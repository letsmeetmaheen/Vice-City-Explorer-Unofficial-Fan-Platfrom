"use client";
import { useEffect, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";

const KEY = "vce-intro-seen";

export default function Intro() {
  const [show, setShow] = useState(false);
  const reduce = useReducedMotion();

  useEffect(() => {
    let seen = false;
    try { seen = localStorage.getItem(KEY) === "1"; } catch {}
    if (seen || reduce) return;
    setShow(true);
    const t = setTimeout(close, 4200);
    return () => clearTimeout(t);
  }, [reduce]);

  function close() {
    try { localStorage.setItem(KEY, "1"); } catch {}
    setShow(false);
  }

  return (
    <AnimatePresence>
      {show && (
        <motion.div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-ink"
          exit={{ opacity: 0 }} transition={{ duration: 0.8 }}>
          <motion.div className="absolute h-px w-0 bg-gradient-to-r from-transparent via-pink to-transparent"
            animate={{ width: "70%" }} transition={{ duration: 1.2, ease: "easeOut" }} />
          <motion.h1 className="font-game text-3xl md:text-6xl tracking-[0.3em] text-gradient text-center"
            initial={{ opacity: 0, letterSpacing: "0.8em" }} animate={{ opacity: 1, letterSpacing: "0.3em" }}
            transition={{ delay: 0.8, duration: 1.4 }}>VICE CITY<br />EXPLORER</motion.h1>
          <motion.p className="mt-6 text-muted tracking-widest uppercase text-xs md:text-sm"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 2 }}>
            The city never sleeps. Neither should you.
          </motion.p>
          <button onClick={close} className="absolute bottom-8 right-8 text-sm text-muted hover:text-white border border-white/15 rounded-full px-4 py-2">
            Skip intro →
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
