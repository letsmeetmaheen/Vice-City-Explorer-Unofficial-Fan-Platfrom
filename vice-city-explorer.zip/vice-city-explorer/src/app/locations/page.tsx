import LocationCard from "@/components/LocationCard";
import EmptyState from "@/components/EmptyState";
import { getLocations } from "@/lib/data";

export const dynamic = "force-dynamic";

export default async function LocationsPage() {
  const { data, error } = await getLocations();
  return (
    <div className="mx-auto max-w-7xl px-6 pt-32 pb-24">
      <h1 className="font-display text-5xl font-bold mb-2">All <span className="text-gradient">locations</span></h1>
      <p className="text-muted mb-12">{data.length} places loaded from the database.</p>
      {data.length ? <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">{data.map((l) => <LocationCard key={l.id} loc={l} />)}</div> : <EmptyState reason={error} />}
    </div>
  );
}
