import type { Location } from "@/lib/types";
import { MapPin } from "lucide-react";

export default function LocationCard({ loc }: { loc: Location }) {
  return (
    <article className="glass neon-border rounded-2xl overflow-hidden group">
      <div className="aspect-video bg-plum relative overflow-hidden">
        {loc.image_url
          // eslint-disable-next-line @next/next/no-img-element
          ? <img src={loc.image_url} alt={loc.name} className="w-full h-full object-cover group-hover:scale-105 transition duration-700" />
          : <div className="w-full h-full sunset-bg" />}
        <span className="absolute top-3 left-3 text-[10px] uppercase tracking-widest bg-ink/70 rounded-full px-3 py-1 text-cyan">{loc.category}</span>
      </div>
      <div className="p-5">
        <h3 className="font-display text-xl font-semibold">{loc.name}</h3>
        <p className="text-xs text-muted flex items-center gap-1 mt-1"><MapPin size={12} />{loc.district}</p>
        <p className="text-sm text-muted mt-3 line-clamp-3">{loc.description}</p>
      </div>
    </article>
  );
}
