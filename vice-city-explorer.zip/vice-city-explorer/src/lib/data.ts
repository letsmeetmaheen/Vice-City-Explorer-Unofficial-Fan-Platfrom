import { createClient } from "./supabase/server";
import { isSupabaseConfigured } from "./supabase/config";
import type { Location } from "./types";

export async function getLocations(): Promise<{ data: Location[]; error: string | null }> {
  if (!isSupabaseConfigured) return { data: [], error: "not-configured" };
  const supabase = await createClient();
  const { data, error } = await supabase.from("locations").select("*").order("name");
  return { data: (data as Location[]) ?? [], error: error?.message ?? null };
}
