"use client";
import dynamic from "next/dynamic";
import type { Location } from "@/lib/types";
const CityMap = dynamic(() => import("./CityMap"), { ssr: false, loading: () => <div className="h-full grid place-items-center text-muted">Loading map…</div> });
export default function MapLoader({ locations }: { locations: Location[] }) { return <CityMap locations={locations} />; }
