"use client";
import { useActionState } from "react";
import { addLocation } from "@/app/dashboard/actions";

const field = "w-full rounded-xl bg-ink/70 border border-white/10 px-4 py-2.5 outline-none focus:border-cyan text-sm";

export default function AddLocationForm() {
  const [state, action, pending] = useActionState(addLocation, { error: null });
  return (
    <form action={action} className="grid md:grid-cols-2 gap-4">
      <input name="name" placeholder="Name" className={field} required />
      <input name="district" placeholder="District" className={field} required />
      <input name="category" placeholder="Category (Beach, Nightlife…)" className={field} required />
      <input name="image_url" placeholder="Image URL (optional, your own art)" className={field} />
      <input name="lat" placeholder="Latitude e.g. 25.79" className={field} required />
      <input name="lng" placeholder="Longitude e.g. -80.13" className={field} required />
      <textarea name="description" placeholder="Description" className={`${field} md:col-span-2 h-24`} required />
      {state?.error && <p className="text-gold text-sm md:col-span-2">{state.error}</p>}
      {state?.ok && <p className="text-cyan text-sm md:col-span-2">Location saved.</p>}
      <button disabled={pending} className="md:col-span-2 rounded-xl bg-pink text-ink font-semibold py-3 disabled:opacity-50">{pending ? "Saving…" : "Add location"}</button>
    </form>
  );
}
