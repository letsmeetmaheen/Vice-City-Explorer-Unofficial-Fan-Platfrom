"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { z } from "zod";
import { createClient } from "@/lib/supabase/client";
import { isSupabaseConfigured } from "@/lib/supabase/config";

const schema = z.object({ email: z.string().email("Enter a valid email"), password: z.string().min(8, "At least 8 characters") });

export default function LoginPage() {
  const [mode, setMode] = useState<"in" | "up">("in");
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setMsg(null);
    const parsed = schema.safeParse(Object.fromEntries(new FormData(e.currentTarget)));
    if (!parsed.success) return setMsg(parsed.error.issues[0].message);
    if (!isSupabaseConfigured) return setMsg("Supabase isn't configured yet — add your keys to .env.local.");
    setBusy(true);
    const supabase = createClient();
    const { email, password } = parsed.data;
    const res = mode === "in"
      ? await supabase.auth.signInWithPassword({ email, password })
      : await supabase.auth.signUp({ email, password, options: { emailRedirectTo: `${location.origin}/auth/callback` } });
    setBusy(false);
    if (res.error) return setMsg(res.error.message);
    if (mode === "up" && !res.data.session) return setMsg("Check your email to confirm your account.");
    router.push("/dashboard"); router.refresh();
  }

  return (
    <div className="min-h-screen sunset-bg grid place-items-center px-6 pt-16">
      <form onSubmit={submit} className="glass neon-border rounded-3xl p-10 w-full max-w-md space-y-5">
        <h1 className="font-game tracking-widest text-xl">{mode === "in" ? "SIGN IN" : "CREATE ACCOUNT"}</h1>
        <input name="email" type="email" placeholder="Email" className="w-full rounded-xl bg-ink/70 border border-white/10 px-4 py-3 outline-none focus:border-cyan" />
        <input name="password" type="password" placeholder="Password" className="w-full rounded-xl bg-ink/70 border border-white/10 px-4 py-3 outline-none focus:border-cyan" />
        {msg && <p className="text-sm text-gold">{msg}</p>}
        <button disabled={busy} className="w-full rounded-xl bg-pink text-ink font-semibold py-3 disabled:opacity-50">{busy ? "Please wait…" : mode === "in" ? "Sign in" : "Sign up"}</button>
        <button type="button" onClick={() => setMode(mode === "in" ? "up" : "in")} className="w-full text-sm text-muted hover:text-white">
          {mode === "in" ? "New here? Create an account" : "Already have an account? Sign in"}
        </button>
      </form>
    </div>
  );
}
