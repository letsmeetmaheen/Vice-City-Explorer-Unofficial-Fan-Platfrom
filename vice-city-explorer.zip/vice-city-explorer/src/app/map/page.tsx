import MapLoader from "@/components/MapLoader";
import { getLocations } from "@/lib/data";

export const dynamic = "force-dynamic";

export default async function MapPage() {
  const { data, error } = await getLocations();
  return (
    <div className="mx-auto max-w-7xl px-6 pt-28 pb-16">
      <h1 className="font-display text-4xl font-bold mb-2">City <span className="text-gradient">map</span></h1>
      <p className="text-muted mb-6 text-sm">{error === "not-configured" ? "Database not connected — the map works, markers appear once Supabase is set up." : `${data.length} locations pinned.`}</p>
      <div className="h-[70vh] glass rounded-2xl p-1"><MapLoader locations={data} /></div>
    </div>
  );
}
