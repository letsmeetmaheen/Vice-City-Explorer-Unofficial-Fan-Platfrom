import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { isSupabaseConfigured } from "@/lib/supabase/config";
import EmptyState from "@/components/EmptyState";
import AddLocationForm from "@/components/AddLocationForm";
import { signOut } from "./actions";

export const dynamic = "force-dynamic";

export default async function Dashboard() {
  if (!isSupabaseConfigured) return <div className="pt-32 pb-24 px-6"><EmptyState reason="not-configured" /></div>;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const { data: profile } = await supabase.from("profiles").select("role, username").eq("id", user.id).single();
  const { count } = await supabase.from("locations").select("*", { count: "exact", head: true });
  const isAdmin = profile?.role === "admin";

  return (
    <div className="mx-auto max-w-5xl px-6 pt-32 pb-24 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-4xl font-bold">Welcome, <span className="text-gradient">{profile?.username ?? user.email}</span></h1>
          <p className="text-muted text-sm mt-1">Role: {profile?.role ?? "member"} · {count ?? 0} locations in the database</p>
        </div>
        <form action={signOut}><button className="glass rounded-full px-5 py-2 text-sm">Sign out</button></form>
      </div>
      {isAdmin ? (
        <section className="glass rounded-2xl p-8">
          <h2 className="font-game text-sm tracking-widest text-cyan mb-6">ADMIN · ADD LOCATION</h2>
          <AddLocationForm />
        </section>
      ) : (
        <p className="glass rounded-2xl p-8 text-muted text-sm">You&apos;re signed in as a member. Admin tools appear here once your role is set to <code>admin</code> in the profiles table.</p>
      )}
    </div>
  );
}
